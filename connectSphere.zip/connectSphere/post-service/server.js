const express = require('express');
const mongoose = require('mongoose');
const redis = require('redis');

const app = express();
app.use(express.json());

const mongoUri = process.env.MONGO_URI || 'mongodb://mongo:27017/post_db';
const redisHost = process.env.REDIS_HOST || 'redis';
const redisPort = process.env.REDIS_PORT || 6379;

mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

const redisClient = redis.createClient({ url: `redis://${redisHost}:${redisPort}` });
redisClient.connect().catch(console.error);

const PostSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  content: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});
const Post = mongoose.model('Post', PostSchema);

app.post('/posts', async (req, res) => {
  const { userId, content } = req.body;
  try {
    const post = new Post({ userId, content });
    await post.save();
    await redisClient.del('posts_cache');
    res.status(201).json(post);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/posts', async (req, res) => {
  const cachedPosts = await redisClient.get('posts_cache');
  if (cachedPosts) {
    return res.json(JSON.parse(cachedPosts));
  }
  const posts = await Post.find().sort({ createdAt: -1 });
  await redisClient.setEx('posts_cache', 300, JSON.stringify(posts));
  res.json(posts);
});

app.listen(3002, () => console.log('Post service running on port 3002'));
