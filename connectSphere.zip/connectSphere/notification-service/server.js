const express = require('express');
const redis = require('redis');

const app = express();
app.use(express.json());

const redisHost = process.env.REDIS_HOST || 'redis';
const redisPort = process.env.REDIS_PORT || 6379;

const redisClient = redis.createClient({ url: `redis://${redisHost}:${redisPort}` });
redisClient.connect().catch(console.error);

app.post('/notify', async (req, res) => {
  const { userId, message } = req.body;
  try {
    await redisClient.lPush(`notifications:${userId}`, JSON.stringify({ message, createdAt: new Date() }));
    res.status(201).json({ message: 'Notification queued' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/notifications/:userId', async (req, res) => {
  const { userId } = req.params;
  try {
    const notifications = await redisClient.lRange(`notifications:${userId}`, 0, -1);
    res.json(notifications.map(n => JSON.parse(n)));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.listen(3003, () => console.log('Notification service running on port 3003'));
